'''
def depthFirstSearch(problem):
  """
  Search the deepest nodes in the search tree first.

  Your search algorithm needs to return a list of actions that reaches the
  goal. Make sure to implement a graph search algorithm.

  To get started, you might want to try some of these simple commands to
  understand the search problem that is being passed in:

  print("Start:", problem.getStartState())
  print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
  print("Start's successors:", problem.getSuccessors(problem.getStartState()))
  """

  # Initialize the frontier and explored set

  frontier = [problem.getStartState()]
  explored = set()

  # Loop until the frontier is empty

  while frontier:
    # Pop the next state from the frontier

    state = frontier.pop()

    # If the state is a goal, return the solution

    if problem.isGoalState(state):
      return problem.getActions(state)

    # Mark the state as explored

    explored.add(state)

    # Add the successors of the state to the frontier

    for successor, action in problem.getSuccessors(state):
      if successor not in explored:
        frontier.append((successor, action))
'''