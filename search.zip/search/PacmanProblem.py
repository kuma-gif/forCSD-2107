"""
class PacmanProblem(SearchProblem):

  def __init__(self, maze, pacman_position):
    self.maze = maze
    self.pacman_position = pacman_position

  def getStartState(self):
    return self.pacman_position

  def isGoalState(self, state):
    return state in self.maze.getFood()

  def getSuccessors(self, state):
    successors = []
    for direction in ["up", "down", "left", "right"]:
      new_position = self.maze.getPositionAfterMove(state, direction)
      if new_position is not None:
        successors.append((new_position, direction))
    return successors
"""